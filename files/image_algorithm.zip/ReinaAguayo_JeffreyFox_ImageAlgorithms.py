import matplotlib.pyplot as plt
import os.path
import numpy as np
import PIL
import PIL.ImageDraw
'''
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'Goku_Vegeta_ImageAlgorithm.jpg')
img = plt.imread(filename)
fig, ax = plt.subplots(1,1)
ax.imshow(img,interpolation='none')
fig.show()

'''


def saveFile(img, filename):
    directory = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(directory, filename)
    img.save(filepath)
    
'''    


#This is changing the color of the hair of Vegeta
height = len(img)
width = len(img[0])
for row in range(0, 370):
    for column in range(0, 560):
        if sum(img[row][column])>=300 and sum(img[row][column])<=400:
            img[row][column] = [0,255,255]
fig.show()
 
'''#changes goku's hair'''

'''
 #messes with Goku's hair         
for row in range(0, height/2):
    for column in range(width/2, width):
        #detecting a color in a range of 300 to 450 to change
          if sum(img[row][column])>=300 and sum(img[row][column])<=450:
              img[row][column] = [0, 255, 255]
fig.show()
'''

#finds image of fire
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'fire_ImageAlgorithm.jpg')
img = plt.imread(filename)
fig, ax = plt.subplots(1,1)
ax.imshow(img,interpolation='none')
fig.show()
#Used this to save new image after modifications were made.
'''img = PIL.Image.fromarray(img)
save_file(img, "Goku_Vegeta_ImageAlgorithm.jpg")
'''

#finds new goku and vegeta image that was saved after it has been modified
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'Goku_Vegeta_ImageAlgorithm_2.jpg')
img = plt.imread(filename)
fig, ax = plt.subplots(1,1)
ax.imshow(img,interpolation='none')
fig.show()


directory = os.path.dirname(os.path.abspath(__file__))
Goku_Vegeta_filename = os.path.join(directory, "Goku_Vegeta_ImageAlgorithm_2.jpg")
Goku_Vegeta_img = PIL.Image.open(Goku_Vegeta_filename)
Goku_Vegeta_resize = Goku_Vegeta_img.resize((700, 450))
fig2, axes2 = plt.subplots(1, 2)
axes2[0].imshow(Goku_Vegeta_img)
axes2[1].imshow(Goku_Vegeta_resize)
ax.imshow(img, interpolation='none')
fig2.show()


'''
Goku_Vegeta_resize.save('Goku_Vegeta_resize.jpg')
'''

img3 = 'Goku_Vegeta_resize.jpg'


#makes edited Goku image a PIL image
'''
img3 = PIL.Image.fromarray(img)
saveFile(img3, 'Goku_Vegeta_resize_PIL.jpg')
'''






directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'fire_ImageAlgorithm.jpg')
img = plt.imread(filename)
fig, ax = plt.subplots(1,1)
ax.imshow(img,interpolation='none')
fig.show()

img4 = 'fire_ImageAlgorithm.jpg'

#makes fire image a PIL image

img4 = PIL.Image.fromarray(img)
saveFile(img4, 'fire_PIL_Image.jpg')

fire_img = 'fire_PIL_image.jpg'
Goku_img = 'Goku_Vegeta_resize_PIL.jpg'

directory = os.path.dirname(os.path.abspath(__file__))
fire_file = os.path.join(directory, 'fire_PIL_Image.jpg')
fire_img = PIL.Image.open(fire_file)
fig, ax = plt.subplots(1,2)
ax[0].imshow(img,interpolation='none')
ax[0].imshow(fire_img, interpolation='none')


image = PIL.Image.open(Goku_img)
logo = PIL.Image.open('fire_PIL_Image.jpg')
image_copy = image.copy()
position = ((image_copy.width - logo.width), (image_copy.height - logo.height))
image_copy.paste(logo, position)
image_copy.save('pasted_image.jpg')




















